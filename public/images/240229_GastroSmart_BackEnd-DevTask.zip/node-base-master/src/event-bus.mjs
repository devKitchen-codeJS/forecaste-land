import EventEmitter from "node:events";

class EventBus extends EventEmitter{
    constructor() {
        super();
    }
}
