export const payloadSchema = {
	type: "object",
	properties: {
		streamId: {
			type: "bigint"
		},

	}
}
