class Cli{
    get allowedCommands(){
        return [];
    }
    constructor() {

    }
    processArgs(){

    }
}
