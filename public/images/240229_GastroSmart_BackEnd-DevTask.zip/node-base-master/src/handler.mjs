class Handler{
    constructor() {
    }
    handle(dataTransport, contexts){

    }
}
